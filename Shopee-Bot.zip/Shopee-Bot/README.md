# Shopee-Bot

Shopee-Bot processes Shopee URLs through the official **Shopee Affiliate Open
API**. It starts in **dry-run** mode, so links are acknowledged without
contacting Shopee until the provider has been configured and live processing has
been explicitly enabled.

## Requirements

- Python 3.11 or newer

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e .
shopee-bot status
shopee-bot run --task inspect
```

The module form also works without installing the package:

```bash
python -m shopee_bot status
```

Start the Telegram polling bot after adding `TELEGRAM_BOT_TOKEN` as a Replit
Secret:

```bash
shopee-bot telegram
```

Run the built-in checks without additional test dependencies:

```bash
python -m unittest discover -s tests
```

## Configuration

Configuration is read from environment variables:

| Variable | Default | Description |
| --- | --- | --- |
| `SHOPEE_BOT_MODE` | `dry-run` | `dry-run` or `live` |
| `SHOPEE_BOT_REGION` | `sg` | Shopee region code |
| `SHOPEE_BOT_LOG_LEVEL` | `INFO` | Log level for future handlers |
| `SHOPEE_AFFILIATE_APP_ID` | — | Shopee Affiliate Open API App ID, stored as a Replit Secret |
| `SHOPEE_AFFILIATE_SECRET` | — | Shopee Affiliate Open API signing secret, stored as a Replit Secret |
| `SHOPEE_AFFILIATE_ENDPOINT` | region default | Optional HTTPS GraphQL endpoint override |
| `SHOPEE_AFFILIATE_SUB_ID` | — | Optional tracking sub-ID sent to Shopee |
| `SHOPEE_AFFILIATE_TIMEOUT_SECONDS` | `15` | Provider request timeout |
| `SHOPEE_BOT_LIVE_ENABLED` | `false` | Explicit second gate for live provider calls |
| `TELEGRAM_BOT_TOKEN` | — | Telegram BotFather token stored as a secret |

### Enable the real provider flow

1. Apply for Shopee Affiliate Open API access for the region in use and create
   an App ID and secret.
2. Add `SHOPEE_AFFILIATE_APP_ID` and `SHOPEE_AFFILIATE_SECRET` as Replit
   Secrets. Never put either credential in source code, `.env` files, Telegram
   messages, or logs.
3. Keep `SHOPEE_BOT_MODE=dry-run` while testing the Telegram acknowledgement
   path. The bot does not contact Shopee in this mode.
4. After verifying the provider account, endpoint, and tracking behavior, set
   `SHOPEE_BOT_MODE=live` and `SHOPEE_BOT_LIVE_ENABLED=true`.

When live processing is enabled, each incoming Shopee URL is signed and sent to
`generateShortLink`. The reply contains the real affiliate link returned by
Shopee. The Affiliate Open API creates a trackable link; it does not withdraw a
user's existing cashback balance or guarantee a commission.