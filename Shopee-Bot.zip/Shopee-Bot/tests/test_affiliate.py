import hashlib
import json
import unittest

from shopee_bot.affiliate import ShopeeAffiliateClient, ShopeeAffiliateError


class FakeResponse:
    def __init__(self, body: dict[str, object]) -> None:
        self._body = json.dumps(body).encode("utf-8")

    def read(self) -> bytes:
        return self._body

    def __enter__(self) -> "FakeResponse":
        return self

    def __exit__(self, *_args: object) -> None:
        return None


class CapturingOpener:
    def __init__(self, response_body: dict[str, object]) -> None:
        self.request = None
        self.response_body = response_body

    def __call__(self, request: object, **_kwargs: object) -> FakeResponse:
        self.request = request
        return FakeResponse(self.response_body)


class AffiliateClientTests(unittest.TestCase):
    def test_generate_short_link_signs_the_exact_request_body(self) -> None:
        opener = CapturingOpener(
            {"data": {"generateShortLink": {"shortLink": "https://s.shopee.sg/abc"}}}
        )
        client = ShopeeAffiliateClient(
            "app-123",
            "secret-456",
            "https://open-api.affiliate.shopee.com.sg/graphql",
            opener=opener,
            clock=lambda: 1_700_000_000,
        )

        result = client.generate_short_link(
            "https://shopee.sg/product/1?name=tea",
            "telegram",
        )

        self.assertEqual(result, "https://s.shopee.sg/abc")
        request = opener.request
        self.assertIsNotNone(request)
        body = request.data.decode("utf-8")
        expected_signature = hashlib.sha256(
            ("app-1231700000000" + body + "secret-456").encode("utf-8")
        ).hexdigest()
        self.assertIn(
            f"Credential=app-123, Signature={expected_signature}, "
            "Timestamp=1700000000",
            request.headers["Authorization"],
        )
        payload = json.loads(body)
        self.assertIn(
            'originUrl: "https://shopee.sg/product/1?name=tea", '
            'subIds: ["telegram"]',
            payload["query"],
        )

    def test_provider_errors_do_not_expose_credentials(self) -> None:
        opener = CapturingOpener(
            {"errors": [{"message": "invalid secret-456 for app-123"}]}
        )
        client = ShopeeAffiliateClient(
            "app-123",
            "secret-456",
            "https://open-api.affiliate.shopee.com.sg/graphql",
            opener=opener,
        )

        with self.assertRaisesRegex(ShopeeAffiliateError, r"\[redacted\]"):
            client.generate_short_link("https://shopee.sg/product/1")

        with self.assertRaises(ShopeeAffiliateError) as raised:
            client.generate_short_link("https://shopee.sg/product/1")
        self.assertNotIn("secret-456", str(raised.exception))
        self.assertNotIn("app-123", str(raised.exception))

    def test_non_shopee_url_is_rejected_before_network_request(self) -> None:
        opener = CapturingOpener({})
        client = ShopeeAffiliateClient(
            "app-123",
            "secret-456",
            "https://open-api.affiliate.shopee.com.sg/graphql",
            opener=opener,
        )

        with self.assertRaises(ShopeeAffiliateError):
            client.generate_short_link("https://shopee.sg.example.com/product/1")
        self.assertIsNone(opener.request)


if __name__ == "__main__":
    unittest.main()