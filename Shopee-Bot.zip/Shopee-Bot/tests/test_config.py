import unittest

from shopee_bot.config import Settings, load_settings
from shopee_bot.telegram_bot import extract_shopee_link, is_shopee_link


class SettingsTests(unittest.TestCase):
    def test_load_settings_uses_defaults(self) -> None:
        settings = load_settings({})

        self.assertEqual(settings, Settings())
        self.assertTrue(settings.is_dry_run)

    def test_load_settings_normalizes_values(self) -> None:
        settings = load_settings(
            {
                "SHOPEE_BOT_MODE": "LIVE",
                "SHOPEE_BOT_REGION": "MY",
                "SHOPEE_BOT_LOG_LEVEL": "debug",
                "SHOPEE_AFFILIATE_APP_ID": "app-123",
                "SHOPEE_AFFILIATE_SECRET": "secret-456",
                "SHOPEE_AFFILIATE_SUB_ID": "telegram",
                "SHOPEE_AFFILIATE_TIMEOUT_SECONDS": "10",
                "SHOPEE_BOT_LIVE_ENABLED": "yes",
            }
        )

        self.assertEqual(settings.mode, "live")
        self.assertEqual(settings.region, "my")
        self.assertEqual(settings.log_level, "DEBUG")
        self.assertEqual(settings.affiliate_app_id, "app-123")
        self.assertEqual(settings.affiliate_secret, "secret-456")
        self.assertEqual(settings.affiliate_sub_id, "telegram")
        self.assertEqual(settings.affiliate_timeout_seconds, 10)
        self.assertTrue(settings.affiliate_configured)
        self.assertTrue(settings.can_process_affiliate_links)

    def test_live_processing_requires_explicit_enablement(self) -> None:
        settings = load_settings(
            {
                "SHOPEE_BOT_MODE": "live",
                "SHOPEE_AFFILIATE_APP_ID": "app-123",
                "SHOPEE_AFFILIATE_SECRET": "secret-456",
            }
        )

        self.assertTrue(settings.affiliate_configured)
        self.assertFalse(settings.can_process_affiliate_links)

    def test_invalid_mode_is_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "mode must be one of"):
            Settings(mode="unsupported")

    def test_shopee_link_detection(self) -> None:
        self.assertTrue(is_shopee_link("https://shopee.co.id/example"))
        self.assertTrue(
            is_shopee_link("Check this: https://www.shopee.com.my/product")
        )
        self.assertFalse(is_shopee_link("https://example.com/shopee/product"))
        self.assertFalse(is_shopee_link("shopee is a marketplace"))

    def test_extract_shopee_link_does_not_return_surrounding_message(self) -> None:
        self.assertEqual(
            extract_shopee_link(
                "Mua hàng tại https://www.shopee.com.my/product?id=42."
            ),
            "https://www.shopee.com.my/product?id=42",
        )


if __name__ == "__main__":
    unittest.main()
