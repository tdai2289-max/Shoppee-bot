---
name: Telegram bot secrets
description: Security rule for Telegram polling credentials in this project.
---

Telegram bot tokens must come from Replit Secrets, never from source code or
chat content.

**Why:** A token pasted into a conversation can be copied and abused, and a
source-embedded token can leak through version history.

**How to apply:** Use the TELEGRAM_BOT_TOKEN secret at runtime and require
rotation in BotFather whenever a token has been exposed.

The Telegram client can include rejected tokens in HTTP and exception logs, so
keep its verbose loggers suppressed during polling startup and surface only a
generic credential error.