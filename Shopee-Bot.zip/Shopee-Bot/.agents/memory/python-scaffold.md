---
name: Python scaffold conventions
description: Conventions for keeping the Python starter runnable in the base environment.
---

Prefer Python standard-library tooling for the initial project scaffold unless a
real feature requires an external dependency.

**Why:** The base runtime does not guarantee that common developer tools such as
pytest are installed, while the starter should run immediately after creation.

**How to apply:** Use `pyproject.toml` for package metadata and a console entry
point, keep the initial CLI dependency-free, and use `unittest` for baseline
checks until project requirements justify adding packages.