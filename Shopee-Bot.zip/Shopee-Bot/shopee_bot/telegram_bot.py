"""Telegram polling bot for Shopee-Bot."""

from __future__ import annotations

import logging
import os
import asyncio
from typing import Any
from urllib.parse import urlparse

from telegram import Update
from telegram.error import InvalidToken
from telegram.ext import (
    Application,
    ApplicationBuilder,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

from .affiliate import (
    ShopeeAffiliateClient,
    ShopeeAffiliateError,
    is_shopee_hostname,
)
from .config import Settings, load_settings

LOGGER = logging.getLogger(__name__)
TOKEN_ENV_VAR = "TELEGRAM_BOT_TOKEN"


def extract_shopee_link(text: str) -> str | None:
    """Return the first HTTP(S) Shopee URL in a message."""

    for word in text.split():
        candidate = word.strip(".,!?()[]{}<>\"'")
        parsed = urlparse(candidate)
        hostname = (parsed.hostname or "").lower().removeprefix("www.")
        if (
            parsed.scheme in {"http", "https"}
            and is_shopee_hostname(hostname)
        ):
            return candidate
    return None


def is_shopee_link(text: str) -> bool:
    """Return whether text contains an HTTP(S) Shopee URL."""

    return extract_shopee_link(text) is not None


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle the /start command."""

    del context
    if update.message is not None:
        await update.message.reply_text(
            "Xin chào! Tôi là Bot Shopee Hoàn Xu. "
            "Hãy gửi link Shopee để kiểm tra!"
        )


async def handle_message(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Process Shopee links when live affiliate processing is explicitly enabled."""

    if update.message is None or not update.message.text:
        return

    text = update.message.text
    link = extract_shopee_link(text)
    if link is None:
        await update.message.reply_text(
            "Vui lòng gửi một đường dẫn Shopee hợp lệ."
        )
        return

    application = getattr(context, "application", None)
    bot_data = getattr(application, "bot_data", {})
    settings = bot_data.get("settings") or load_settings()
    if not settings.live_enabled or settings.mode == "dry-run":
        await update.message.reply_text(
            f"Đã nhận link Shopee: {link}\n"
            "Chế độ an toàn đang bật; chưa gọi nhà cung cấp hoàn xu."
        )
        return

    if not settings.affiliate_configured:
        await update.message.reply_text(
            "Không thể xử lý link lúc này: Shopee Affiliate API chưa được cấu hình. "
            "Hãy thêm SHOPEE_AFFILIATE_APP_ID và SHOPEE_AFFILIATE_SECRET vào "
            "Replit Secrets."
        )
        return

    await update.message.reply_text("Đã nhận link Shopee. Đang tạo link hoàn xu...")
    client = ShopeeAffiliateClient(
        app_id=settings.affiliate_app_id,
        secret=settings.affiliate_secret,
        endpoint=settings.affiliate_endpoint,
        timeout_seconds=settings.affiliate_timeout_seconds,
    )
    try:
        affiliate_link = await asyncio.to_thread(
            client.generate_short_link,
            link,
            settings.affiliate_sub_id,
        )
    except ShopeeAffiliateError as error:
        LOGGER.warning("Shopee Affiliate API request failed: %s", error)
        await update.message.reply_text(
            f"Nhà cung cấp Shopee không thể xử lý link: {error}"
        )
        return

    await update.message.reply_text(
        "Đã tạo link Shopee Affiliate thành công:\n"
        f"{affiliate_link}\n\n"
        "Hãy mở link này để đơn hàng được ghi nhận theo điều kiện của Shopee."
    )


def get_token() -> str:
    """Read the Telegram bot token from the environment."""

    token = os.environ.get(TOKEN_ENV_VAR, "").strip()
    if not token:
        raise RuntimeError(
            f"{TOKEN_ENV_VAR} is not configured. "
            "Add it as a Replit Secret before starting the Telegram bot."
        )
    return token


def build_application(
    token: str | None = None,
    settings: Settings | None = None,
) -> Application[Any, Any, Any, Any, Any, Any]:
    """Build the Telegram application and register handlers."""

    application = ApplicationBuilder().token(token or get_token()).build()
    application.bot_data["settings"] = settings or load_settings()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(
        MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message)
    )
    return application


def run_polling() -> None:
    """Start the Telegram bot and keep polling until interrupted."""

    logging.basicConfig(
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        level=logging.INFO,
    )
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("telegram.ext").setLevel(logging.CRITICAL)
    LOGGER.info("Shopee-Bot Telegram polling started")
    try:
        build_application().run_polling()
    except InvalidToken:
        raise RuntimeError(
            "Telegram rejected TELEGRAM_BOT_TOKEN. "
            "Rotate it in @BotFather and update the Replit Secret."
        ) from None