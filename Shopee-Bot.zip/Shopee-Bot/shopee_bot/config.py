"""Configuration loading for Shopee-Bot."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Mapping


VALID_MODES = frozenset({"dry-run", "live"})
SHOPEE_AFFILIATE_ENDPOINTS = {
    "br": "https://open-api.affiliate.shopee.com.br/graphql",
    "id": "https://open-api.affiliate.shopee.co.id/graphql",
    "my": "https://open-api.affiliate.shopee.com.my/graphql",
    "ph": "https://open-api.affiliate.shopee.ph/graphql",
    "sg": "https://open-api.affiliate.shopee.com.sg/graphql",
    "th": "https://open-api.affiliate.shopee.co.th/graphql",
    "tw": "https://open-api.affiliate.shopee.tw/graphql",
    "vn": "https://open-api.affiliate.shopee.vn/graphql",
}
TRUE_VALUES = frozenset({"1", "true", "yes", "on"})


@dataclass(frozen=True, slots=True)
class Settings:
    """Runtime settings loaded from environment variables."""

    mode: str = "dry-run"
    region: str = "sg"
    log_level: str = "INFO"
    affiliate_app_id: str = field(default="", repr=False)
    affiliate_secret: str = field(default="", repr=False)
    affiliate_endpoint: str = SHOPEE_AFFILIATE_ENDPOINTS["sg"]
    affiliate_sub_id: str = ""
    affiliate_timeout_seconds: float = 15.0
    live_enabled: bool = False

    def __post_init__(self) -> None:
        if self.mode not in VALID_MODES:
            choices = ", ".join(sorted(VALID_MODES))
            raise ValueError(f"mode must be one of {choices}; got {self.mode!r}")
        if not self.region.strip():
            raise ValueError("region cannot be empty")
        if not self.log_level.strip():
            raise ValueError("log_level cannot be empty")
        if not self.affiliate_endpoint.startswith("https://"):
            raise ValueError("affiliate_endpoint must use HTTPS")
        if self.affiliate_timeout_seconds <= 0:
            raise ValueError("affiliate_timeout_seconds must be positive")

    @property
    def is_dry_run(self) -> bool:
        """Whether actions should be simulated instead of executed."""

        return self.mode == "dry-run"

    @property
    def affiliate_configured(self) -> bool:
        """Whether the provider has the credentials required to make requests."""

        return bool(self.affiliate_app_id and self.affiliate_secret)

    @property
    def can_process_affiliate_links(self) -> bool:
        """Whether the explicitly enabled live provider path may run."""

        return (
            self.mode == "live"
            and self.live_enabled
            and self.affiliate_configured
        )


def load_settings(environ: Mapping[str, str] | None = None) -> Settings:
    """Load settings from an environment mapping.

    An explicit mapping makes configuration easy to test without mutating the
    process environment.
    """

    values = os.environ if environ is None else environ
    region = values.get("SHOPEE_BOT_REGION", "sg").strip().lower()
    endpoint = values.get("SHOPEE_AFFILIATE_ENDPOINT", "").strip()
    if not endpoint:
        endpoint = SHOPEE_AFFILIATE_ENDPOINTS.get(
            region,
            f"https://open-api.affiliate.shopee.{region}/graphql",
        )
    timeout_value = values.get("SHOPEE_AFFILIATE_TIMEOUT_SECONDS", "15").strip()
    return Settings(
        mode=values.get("SHOPEE_BOT_MODE", "dry-run").strip().lower(),
        region=region,
        log_level=values.get("SHOPEE_BOT_LOG_LEVEL", "INFO").strip().upper(),
        affiliate_app_id=values.get("SHOPEE_AFFILIATE_APP_ID", "").strip(),
        affiliate_secret=values.get("SHOPEE_AFFILIATE_SECRET", "").strip(),
        affiliate_endpoint=endpoint,
        affiliate_sub_id=values.get("SHOPEE_AFFILIATE_SUB_ID", "").strip(),
        affiliate_timeout_seconds=float(timeout_value),
        live_enabled=values.get("SHOPEE_BOT_LIVE_ENABLED", "")
        .strip()
        .lower()
        in TRUE_VALUES,
    )