"""Shopee Affiliate Open API client.

The official affiliate API creates a trackable Shopee link. It does not
withdraw a user's cashback balance or promise a commission, so callers should
describe the result as an affiliate/cashback link rather than a claimed payout.
"""

from __future__ import annotations

import hashlib
import json
import time
from collections.abc import Callable, Sequence
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from urllib.parse import urlparse


SHOPEE_DOMAINS = frozenset(
    {
        "shopee.com",
        "shopee.com.br",
        "shopee.com.co",
        "shopee.com.mx",
        "shopee.co.id",
        "shopee.co.th",
        "shopee.cl",
        "shopee.com.my",
        "shopee.ph",
        "shopee.pl",
        "shopee.sg",
        "shopee.tw",
        "shopee.vn",
    }
)


def is_shopee_hostname(hostname: str) -> bool:
    """Return whether a hostname is Shopee-owned, not a lookalike domain."""

    return hostname in SHOPEE_DOMAINS or any(
        hostname.endswith(f".{domain}") for domain in SHOPEE_DOMAINS
    )


class ShopeeAffiliateError(RuntimeError):
    """A safe, user-facing provider error."""


def _redact(message: str, secrets: Sequence[str]) -> str:
    """Prevent configured credentials from appearing in an error message."""

    redacted = message
    for secret in secrets:
        if secret:
            redacted = redacted.replace(secret, "[redacted]")
    return " ".join(redacted.split())[:240]


class ShopeeAffiliateClient:
    """Small dependency-free client for generateShortLink."""

    def __init__(
        self,
        app_id: str,
        secret: str,
        endpoint: str,
        timeout_seconds: float = 15.0,
        *,
        opener: Callable[..., Any] = urlopen,
        clock: Callable[[], float] = time.time,
    ) -> None:
        if not app_id.strip() or not secret.strip():
            raise ValueError("Shopee Affiliate App ID and secret are required")
        if not endpoint.startswith("https://"):
            raise ValueError("Shopee Affiliate endpoint must use HTTPS")
        self._app_id = app_id
        self._secret = secret
        self._endpoint = endpoint
        self._timeout_seconds = timeout_seconds
        self._opener = opener
        self._clock = clock

    def generate_short_link(
        self,
        origin_url: str,
        sub_id: str = "",
    ) -> str:
        """Create a trackable affiliate URL for a Shopee product or shop URL."""

        parsed = urlparse(origin_url)
        hostname = (parsed.hostname or "").lower().removeprefix("www.")
        if (
            parsed.scheme not in {"http", "https"}
            or not is_shopee_hostname(hostname)
        ):
            raise ShopeeAffiliateError("The submitted URL is not a valid Shopee link.")

        sub_ids_input = (
            f", subIds: [{json.dumps(sub_id)}]" if sub_id else ""
        )
        query = (
            "mutation { generateShortLink(input: { originUrl: %s%s }) "
            "{ shortLink } }"
            % (json.dumps(origin_url), sub_ids_input)
        )
        payload = {"query": query}
        body = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        timestamp = int(self._clock())
        signature = hashlib.sha256(
            f"{self._app_id}{timestamp}{body}{self._secret}".encode("utf-8")
        ).hexdigest()
        request = Request(
            self._endpoint,
            data=body.encode("utf-8"),
            headers={
                "Authorization": (
                    f"SHA256 Credential={self._app_id}, "
                    f"Signature={signature}, Timestamp={timestamp}"
                ),
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            method="POST",
        )

        try:
            with self._opener(request, timeout=self._timeout_seconds) as response:
                response_body = response.read()
        except HTTPError as error:
            if error.code in {401, 403}:
                raise ShopeeAffiliateError(
                    "Shopee rejected the affiliate credentials. "
                    "Check the App ID, secret, region, and API access."
                ) from error
            if error.code == 429:
                raise ShopeeAffiliateError(
                    "Shopee is rate-limiting requests. Please try again later."
                ) from error
            raise ShopeeAffiliateError(
                f"Shopee Affiliate API returned HTTP {error.code}."
            ) from error
        except (TimeoutError, URLError) as error:
            raise ShopeeAffiliateError(
                "Shopee Affiliate API could not be reached. Please try again later."
            ) from error
        except OSError as error:
            raise ShopeeAffiliateError(
                "Shopee Affiliate API request failed. Please try again later."
            ) from error

        try:
            response_data = json.loads(response_body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise ShopeeAffiliateError(
                "Shopee returned an invalid API response."
            ) from error

        errors = (
            response_data.get("errors")
            if isinstance(response_data, dict)
            else None
        )
        if errors:
            provider_messages = [
                item.get("message", "Unknown provider error")
                for item in errors
                if isinstance(item, dict)
            ]
            message = "; ".join(provider_messages) or "Unknown provider error"
            raise ShopeeAffiliateError(
                "Shopee Affiliate API error: "
                + _redact(message, (self._app_id, self._secret))
            )

        try:
            short_link = response_data["data"]["generateShortLink"]["shortLink"]
        except (KeyError, TypeError) as error:
            raise ShopeeAffiliateError(
                "Shopee returned no affiliate link for this URL."
            ) from error
        if not isinstance(short_link, str) or not short_link.startswith("https://"):
            raise ShopeeAffiliateError(
                "Shopee returned an invalid affiliate link."
            )
        return short_link