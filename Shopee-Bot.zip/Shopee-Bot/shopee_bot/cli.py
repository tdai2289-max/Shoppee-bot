"""Command-line interface for Shopee-Bot."""

from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Sequence

from . import __version__
from .config import Settings, load_settings


def build_parser() -> argparse.ArgumentParser:
    """Create the command-line parser."""

    parser = argparse.ArgumentParser(
        prog="shopee-bot",
        description="A safe foundation for Shopee automation.",
    )
    parser.add_argument("--version", action="version", version=__version__)
    subparsers = parser.add_subparsers(dest="command")

    status = subparsers.add_parser(
        "status",
        help="show the current bot configuration",
    )
    status.set_defaults(handler=_status)

    run = subparsers.add_parser(
        "run",
        help="start the bot in the configured mode",
    )
    run.add_argument(
        "--task",
        default="inspect",
        help="task name to run (default: inspect)",
    )
    run.set_defaults(handler=_run)

    telegram = subparsers.add_parser(
        "telegram",
        help="start the Telegram polling bot",
    )
    telegram.set_defaults(handler=_telegram)
    return parser


def _status(settings: Settings, _args: argparse.Namespace) -> int:
    print(
        json.dumps(
            {
                "name": "Shopee-Bot",
                "version": __version__,
                "mode": settings.mode,
                "region": settings.region,
                "log_level": settings.log_level,
                "affiliate_provider": "Shopee Affiliate Open API",
                "affiliate_configured": settings.affiliate_configured,
                "live_enabled": settings.live_enabled,
            },
            indent=2,
        )
    )
    return 0


def _run(settings: Settings, args: argparse.Namespace) -> int:
    mode_message = "Would run" if settings.is_dry_run else "Running"
    print(
        f"{mode_message} task {args.task!r} for region {settings.region!r} "
        f"in {settings.mode} mode."
    )
    if settings.is_dry_run:
        print("No external actions were performed.")
    else:
        print("Live task handlers are not configured yet.")
    return 0


def _telegram(_settings: Settings, _args: argparse.Namespace) -> int:
    from .telegram_bot import run_polling

    try:
        run_polling()
    except RuntimeError as error:
        print(f"Unable to start Telegram bot: {error}", file=sys.stderr)
        return 2
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    """Run the CLI and return a process exit code."""

    parser = build_parser()
    args = parser.parse_args(argv)
    settings = load_settings()
    handler = getattr(args, "handler", _status)
    return handler(settings, args)


if __name__ == "__main__":
    raise SystemExit(main())