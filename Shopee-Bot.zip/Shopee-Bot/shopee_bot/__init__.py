"""Shopee-Bot: a safe foundation for Shopee automation."""

__version__ = "0.1.0"