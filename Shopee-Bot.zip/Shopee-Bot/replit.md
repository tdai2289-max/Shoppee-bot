# Shopee-Bot

Shopee-Bot is a Python foundation for building safe, extensible Shopee automation.

## Run & Operate

- `python -m shopee_bot status` — show the current configuration
- `python -m shopee_bot run --task inspect` — run a dry-run task
- `python -m unittest discover -s tests` — run the Python test suite
- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- Python 3.11+ with `python-telegram-bot`
- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `shopee_bot/` — Python package and CLI
- `pyproject.toml` — Python project metadata and console entry point
- `tests/` — focused configuration tests

## Architecture decisions

- The CLI defaults to dry-run mode to prevent accidental external actions.
- Credentials are read from Replit Secrets and never stored in source files.

## Product

The project provides configuration loading, a status command, a safe task runner
scaffold, and a Telegram polling bot that can create trackable Shopee affiliate
links through the official Affiliate Open API. Dry-run mode is the default, and
live provider calls require credentials plus an explicit live-enable flag.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
